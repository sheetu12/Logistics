from django.db import models

# Create your models here.

class State(models.Model):
    name = models.CharField(max_length=100)

class Coupon(models.Model):
    Coupon_name = models.CharField(max_length=100)    
    Coupon_discount = models.IntegerField()

class Status(models.Model):
    Status_name = models.CharField(max_length=100)
