from django.contrib import admin
from .models import State
from .models import Coupon
from .models import Status

# Register your models here.
@admin.register(State)
class StateAdmin(admin.ModelAdmin):
    list_display = ['id','name']
@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ['id','Coupon_name','Coupon_discount']
@admin.register(Status)
class Status(admin.ModelAdmin):
    list_display = ['id','Status_name']


