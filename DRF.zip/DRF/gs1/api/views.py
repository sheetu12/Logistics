from django.shortcuts import render
from .models import State
from .models import Coupon
from .models import Status
from .serializers import StateSerializer
from .serializers import CouponSerializer
from .serializers import StatusSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse

# Create your views here.
def state_detail(request, pk):
    state = State.objects.get(id = pk)
    serializer = StateSerializer(state)
    json_data = JSONRenderer().render(serializer.data)
    return HttpResponse(json_data,content_type='application/json')


def coupon_detail(request, pk):
    coupon = Coupon.objects.get(id = pk)
    serializer = CouponSerializer(coupon)
    json_data = JSONRenderer().render(serializer.data)
    return HttpResponse(json_data,content_type='application/json')


def status_detail(request,pk):
    status = Status.objects.get(id = pk)
    serializer = StatusSerializer(status)
    json_data = JSONRenderer().render(serializer.data)
    return HttpResponse(json_data,content_type='application/json')

def state_list(request):
    state = State.objects.all()
    serializer = StateSerializer(state, many=True)
    json_data = JSONRenderer().render(serializer.data)
    return HttpResponse(json_data,content_type='application/json')

def coupon_list(request):
    coupon = Coupon.objects.all()
    serializer = CouponSerializer(coupon, many=True)
    json_data = JSONRenderer().render(serializer.data)
    return HttpResponse(json_data,content_type='application/json')

def status_list(request):
    status = Status.objects.all()
    serializer = StatusSerializer(status,many=True)
    json_data = JSONRenderer().render(serializer.data)
    return HttpResponse(json_data,content_type='application/json')

