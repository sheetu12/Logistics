from rest_framework import serializers
class StateSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=100)

class CouponSerializer(serializers.Serializer):
    Coupon_name = serializers.CharField(max_length=100)    
    Coupon_discount = serializers.IntegerField()

class StatusSerializer(serializers.Serializer):
    Status_name = serializers.CharField(max_length=100)



